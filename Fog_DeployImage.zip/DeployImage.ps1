﻿<#
Description: Script that calls out to Fog Pxe Imaging Server to create a Host entry and start a deploy imaging task.
Requirements: 
-vComamnder 6.1.X or higher https://www.embotics.com
-Powershell V4 or greater
-Fog Version 1.4.4 or greater https://fogproject.org/

Note:
Your Environment may require additional or diffrent settings.  

vCommander workflow Run Syntax:
powershell.exe c:\Scripts\fog\DeployImage.ps1 -MachineName "#{target.settings.customAttribute['Name']}" -MacAddress "#{target.settings.customAttribute['MAC Address']}" -imagename "#{target.settings.customAttribute['Image']}"
#>
            

[CmdletBinding()]
	param(
        [switch]$Elevated,
        [Parameter(Mandatory=$True)]
        [String] $MachineName = $(Throw "Provide the target machines Name"),
        [String] $MacAddress = $(Throw "Provide the target machines MAC Address"),
        [String] $ImageName = $(Throw "Provide the Image Name to assign to the new target host")
        )

#######################################################################################################################
# Configure the variables below for the Fog Server
#######################################################################################################################
    #FogServer
        $fogApiToken = 'Fog Api Token'
        $fogUserToken = 'Fog User Token'
        $fogServer = "fog IP addrress"
        $Description = "Created by vCommander"  
    
########################################################################################################################
# Nothing to configure below this line - Starting the main function of the script
########################################################################################################################

########################################################################################################################
# Setting Cert Policy - required for successful auth with the phpipam API if set to https
########################################################################################################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

########################################################################################################################
    #Setup Auth headers and base url for FogServer
        $headers = @{};
        $headers.Add('fog-api-token', $fogApiToken);
        $headers.Add('fog-user-token', $fogUserToken);
        $baseUri = "http://$fogServer/fog"
    
    #Get Image List From Fog Server
        Try{
            $ImageURL = $baseUri+"/image/"
            $ImageResult = Invoke-RestMethod -Uri $ImageURL -Method GET -Headers $headers -ContentType "application/json"
            $Image = $ImageResult.images | Select-object imageTypeID,id,name | Where-object {$_.name -eq $ImageName}
            }Catch{Write-Host "Failed to get Image data from Fog" -ForegroundColor Red
                $error[0] | Format-List -Force
                Exit 1
                }

    #GetHost List from fog Server ***Not nessicary but nice to have incase you want to use it for other data checks***
        Try{
            $HostURL = $baseUri +"/host/"
            $HostResult = Invoke-RestMethod -Uri $HostURL -Method GET -Headers $headers -ContentType "application/json"
            }Catch{Write-Host "Failed to get HostList from Fog" -ForegroundColor Red
                $error[0] | Format-List -Force
                Exit 1
                }

    #Create Host entry from vCommander
       $HostJson = @{
                           "name"=  $MachineName
                           "description"=  $Description
                           "macs" =  @($MacAddress)
                           "imageID"= $Image.id
                           "imagename" =  $ImageName  
                           }
        Try{                    
            $CreateHostJson = ConvertTo-Json($HostJson)
            $createHostURL = $baseUri +"/host/create"
            $createHostResult = Invoke-RestMethod -Uri $createHostURL -Method POST -body $CreateHostJson -Headers $headers -ContentType "application/json"
           }Catch{Write-Host "Failed to create host in Fog" -ForegroundColor Red
                $error[0] | Format-List -Force
                Exit 1
                }

    #Get Task types to confirm Structure
         Try{
             $TasktypesURL = $baseUri + "/tasktype"
             $TasktypesResult = Invoke-RestMethod -Uri $TasktypesURL -Method GET -Headers $headers -ContentType "application/json"
             $TasktypeID = ($TasktypesResult.tasktypes | Select-object name,id | Where-object {$_.name -eq "Deploy"}).id
             }Catch{Write-Host "Failed to get Task types from Fog" -ForegroundColor Red
                $error[0] | Format-List -Force
                Exit 1
                }

    #Create Task to Image Host    
        $ImageID = $image.id
        $HostID = $createHostResult.id  

        $TaskURL = $baseUri + "/host/" + $HostID + "/task"
        $TaskdataSet = @{
            "hostname" = $createHostResult.name
            "taskTypeID" = $TasktypeID
            }
        Try{
            $taskdataToSend = ConvertTo-JSON($TaskdataSet)
            $TaskResult = Invoke-RestMethod -Method Post -Uri $TaskURL -Headers $headers -Body $taskdataToSend -ContentType "application/json"
            }Catch{Write-Host "Failed to create Deploy Task in Fog" -ForegroundColor Red
                $error[0] | Format-List -Force
                Exit 1
                }

