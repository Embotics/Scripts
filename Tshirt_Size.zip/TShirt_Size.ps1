﻿<#
          
#>

param(
    [Parameter(Mandatory=$true)]
    [Int] $requestid,
    [Parameter(Mandatory=$True)]
    [string] $managedService
)

$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}

import-module VMware.VimAutomation.Core

#Edit your settings here
    #address of your vCommander server
        $vCommanderServer = "localhost" 
        #Credential file to access your vCommander install, this must be prepared in advance
        $vCommanderCreds = 'c:\scripts\vCommanderCreds.xml'

    #Sizing file
        $sizFile = 'c:\scripts\sizingFile.xml'

    #Address of the vCenter
        $VCenterAddress = ''
        #Credentials file for vCenter
        $vCenterCreds = 'c:\scripts\vCenterCreds.xml'
#Do not edit below this line
    
#Connect to vCommander
    $Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $vCommanderCreds) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client

#Get the service request details
    $Request = Get-RequestedServices -requestId $requestId
    $vmName = $Request.RequestedServiceCollection.RequestedServices.deployedService.components.target.displayName
    
    write-host "Address: "$managedService
    
    #Get the vCenter address from the managed service object
    $vCenterAddress = $managedService

    $managedServices = Get-ManagementServers
    foreach($ms in $managedServices.ManagementServerCollection.ManagementServers)
    {
        if($ms.serverType -eq "VMWARE_VC" -and $ms.address -eq $managedService)
        {
            $msID = $ms.id
        }
    }

    $vCenterVMs = Get-VMs -vmName $vmName –max 1 -msId $msID
    $vmRemoteID = $vCenterVMs.VirtualMachineCollection.VirtualMachines[0].remoteID  
  
    $requestedService = Get-RequestedServices -requestId $requestId
    $requestedServiceId = $requestedService.RequestedServiceCollection.RequestedServices.id
    $requestedComponent = Get-RequestedComponents -requestId $requestId -requestedServiceId $requestedServiceId
    $requestedComponentId = $requestedComponent.RequestedComponentCollection.RequestedComponents.id
    $Form = Get-RequestedComponentFormDetails -requestedComponentId $requestedComponentId -requestedServiceId $requestedServiceId -requestId $requestId
    $FormDetails = $Form.RequestFormElementCollection.RequestFormElements
    
    $RequestedSize = $FormDetails | where-object {$_.label -eq 'T-Shirt Size'} | Select -Expandproperty value

    write-host "size: "$RequestedSize

#load the sizing file
    [xml]$sizingFile = Get-Content -Path $sizFile

    if($RequestedSize -eq "Small")
    {
        $cpuNum = $sizingFile.'size-info'.small.CPU
        $memoryNum = $sizingFile.'size-info'.small.Memory
    }
    if($RequestedSize -eq "Medium")
    {
        $cpuNum = $sizingFile.'size-info'.medium.CPU
        $memoryNum = $sizingFile.'size-info'.medium.Memory
    }
    if($RequestedSize -eq "Large")
    {
        $cpuNum = $sizingFile.'size-info'.large.CPU
        $memoryNum = $sizingFile.'size-info'.large.Memory
    }
    
    $VCenterCred = (New-DecryptCredential -keyFilePath $vCenterCreds) 
    #Connect to vCenter   
    $vCenterServer = Connect-VIServer -Server $vCenterAddress

    #Get the VM from vCenter
    $vCenterVMs = VMware.VimAutomation.Core\Get-VM -Name $vmName

    foreach($vm in $vCenterVMs)
    {
        if($vm.Id -like "*$vmRemoteID*")
        {
            $selectedVM = $vm
        }
    }   
    
    #Change the CPU and memory on the VM    
    Stop-VM -vm $selectedVM -Confirm:$false 
    Set-VM -VM $selectedVM -NumCpu $cpuNum -MemoryMB $memoryNum -Confirm:$false 
    Start-VM -vm $selectedVM -Confirm:$false 
