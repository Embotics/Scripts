﻿<#
Description: Script that calls out to Rubrik to assign an SLA to the VM in the completion workflow
Requirements: 
-VComamnder 6.1.4 or higher
-Powershell V4 or greater


Note:
Your Environment may require additional or diffrent logic depending on how Rubrik has been configured.

vCommander workflow Run Syntax:
powershell.exe c:\Scripts\Rubrik\Rubrik_Provisioning_Workflow.ps1 -TargetVMName "#{target.deployedName}" -RemoteID "#{target.remoteId}" -RequestID "{request.id}"
#>



[CmdletBinding()]
	param(
        [Parameter(Mandatory=$True)]
        [String] $TargetVMName = $(Throw "Provide the VM Name to target"),        
		[Parameter(Mandatory=$True)]
        [String] $RemoteID = $(Throw "Provide the remote id to apply to the VM"),
        [Parameter(Mandatory=$true)]
        [Int] $RequestID = $(Throw "Provide the request ID for the Service Request"),
        [Parameter(Mandatory=$True)]
        [String] $VCenterAddress = $(Throw "Provide the vCenter Address which is hosting teh target VM")
        )

########################################################################################################################
# Setting Cert Policy - required for successful auth with the Rubrik API if set to https
########################################################################################################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

$rubrikCreds = "YWSGESVEFSEGHJWRYWElY3JldDE="

$rubrikSessionHeader = @{Authorization=("Basic {0}" -f $rubrikCreds)}
$contentType = "application/json"

    #address of your vCommander server
    $vCommanderServer = "localhost" 
    #Credential file to access your vCommander install, this must be prepared in advance
    $CredFile = 'c:\scripts\vCommanderCreds.xml'

########################################################################################################################
# Variables Passed in by vCommander passed in on the provisioning workflow for a VM
########################################################################################################################


$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}


$Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client

$requestedService = Get-RequestedServices -RequestID $RequestID
$requestedServiceId = $requestedService.RequestedServiceCollection.RequestedServices.id
$requestedComponent = Get-RequestedComponents -RequestID $RequestID -requestedServiceId $requestedServiceId
$requestedComponentId = $requestedComponent.RequestedComponentCollection.RequestedComponents.id
$Form = Get-RequestedComponentFormDetails -requestedComponentId $requestedComponentId -requestedServiceId $requestedServiceId -RequestID $RequestID
$FormDetails = $Form.RequestFormElementCollection.RequestFormElements

$SLAName = ($FormDetails | where {$_.label -eq "Rubrik SLA"}).value

Write-host "TargetVM: $TargetVMName"
Write-Host "Target Remote ID: $RemoteID"
Write-Host "Target vCenter: $VCenterAddress"

########################################################################################################################
# Customer Configured Variables
########################################################################################################################

$rubrikIP = "https://10.10.20.11"

########################################################################################################################
# Get list of vCenters and find the target vCenter hosting the VM
########################################################################################################################
$vCentersListURL =  "$rubrikIP/api/v1/vmware/vcenter"
Try
{
	$vCJSON = Invoke-WebRequest -Uri $vCentersListURL -Headers $rubrikSessionHeader -Method GET
	$vCs = ConvertFrom-Json -InputObject $vCJSON.Content
    $vCenters = $vCs.data


    $hostvCenter = $VCs.data |where {$_.hostname -eq $VCenterAddress}

    if(!$hostvCenter)
    {
        Write-Host "Unable to find selected vCenter" -ForegroundColor Red
	    Exit 1
    }

    ########################################################################################################################
    # Refresh the list of VMs on the selected vCenter
    ########################################################################################################################
    
    $vCenterRefreshURL = "$rubrikIP/api/v1/vmware/vcenter/"+$hostvCenter.id+"/refresh"
    $vCRefreshJSON = Invoke-WebRequest -Uri $vCenterRefreshURL -Headers $rubrikSessionHeader -Method POST
	$vCTask = ConvertFrom-Json -InputObject $vCRefreshJSON.Content

    $vCTaskStatus = $vCTask.status
    $vCTaskStatusURL = "$rubrikIP/api/v1/vmware/vcenter/request/"+$vCTask.id

    While($vCTaskStatus -eq "RUNNING" -or $vCTaskStatus -eq "QUEUED" -or $vCTaskStatus -eq "ACQUIRING")
    {
        Try
        {
	        $vCenterRefreshURL = Invoke-WebRequest -Uri $vCTaskStatusURL -Headers $rubrikSessionHeader -Method GET
            $vCRefreshJSON =  $vCenterRefreshURL.content | ConvertFrom-Json
		    $vCTaskStatus = $vCRefreshJSON.status
        }Catch {
	        Write-Host "Failed to take the Snapshot" -ForegroundColor Red
            $error[0] | Format-List -Force
	        Exit 1
        }  
    }

    if($vCTaskStatus -ne "SUCCEEDED")
    {
        Write-Host "Unable to refresh VM metadata for selected vCenter" -ForegroundColor Red
	    Exit 1
    }

}Catch {
	Write-Host "Unable to find selected vCenter" -ForegroundColor Red
	Exit 1
}  



########################################################################################################################
# Get VMs by Name
########################################################################################################################
$isNotFound = $true

$VMPath = "$rubrikIP/api/v1/vmware/vm?name=$TargetVMName"

while($isNotFound)
{
    Try
    {
	    $VMJSON = Invoke-WebRequest -Uri $VMPath -Headers $rubrikSessionHeader -Method GET
	    $VMs = ConvertFrom-Json -InputObject $VMJSON.Content
        $VMs = $VMs.data

    }Catch {
	    Write-Host "Failed locate selected VM" -ForegroundColor Red
	    Exit 1
    }  

    ########################################################################################################################
    # Get specific VM ID by remote (vCenter) ID
    ########################################################################################################################

    $selectedVM = $VMs | Where-Object {$_.moid -eq $RemoteID}

    if($selectedVM)
    {
        Write-Host "VM found"
        $VMRubrikID = $selectedVM.id

        #Break while loop
        $isNotFound = $false
    }      
}



########################################################################################################################
# Get list of SLAs and save ID of selected SLA
########################################################################################################################
$SLAPath = "$rubrikIP/api/v1/sla_domain?name=$SLAName"

Try
	{
		$SLAJSON = Invoke-WebRequest -Uri $SLAPath -Headers $rubrikSessionHeader -Method GET
		$SLAs = ConvertFrom-Json -InputObject $SLAJSON.Content
        $SLAs = $SLAs.data

	}Catch {
		Write-Host "Failed to retrieve selected SLA" -ForegroundColor Red
		$error[0] | Format-List -Force
		Exit 1
	}  

if($SLAs.Count -lt 1)
{    
    Write-Host "Failed to retrieve selected SLA" -ForegroundColor Red
	Exit 1
}

$SLAID = $SLAs[0].id

########################################################################################################################
# PATCH VM to add SLA
########################################################################################################################
$VMPatchSLAJSON = 
'{
  "configuredSlaDomainId" : "'+$SLAID+'"    
 }'

$VMPatchPath = "$rubrikIP/api/v1/vmware/vm/$VMRubrikID"

Try
{
	$VMJSON = Invoke-WebRequest -Uri $VMPatchPath -Headers $rubrikSessionHeader -Body $VMPatchSLAJSON -Method PATCH
		
}Catch {
	Write-Host "Failed to Apply the selected SLA " -ForegroundColor Red
    $error[0] | Format-List -Force
	Exit 1
}  

Write-Host "The selected SLA has been applied"


