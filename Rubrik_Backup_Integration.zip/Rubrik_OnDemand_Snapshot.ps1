﻿<#
Description: Script that calls out to Rubrik to take an On Demand Snapshot
Requirements: 
-VComamnder 6.1.4 or higher
-Powershell V4 or greater


Note:
Your Environment may require additional or different logic depending on how Rubrik has been configured.

vCommander workflow Run Syntax:
powershell.exe c:\Scripts\Rubrik\Rubrik_OnDemand_Snapshot.ps1 -TargetVMName "#{target.deployedName}" -RemoteID "#{target.remoteId}"
#>



[CmdletBinding()]
	param(
        [Parameter(Mandatory=$True)]
        [String] $TargetVMName = $(Throw "Provide the VM Name to target"),        
		[Parameter(Mandatory=$True)]
        [String] $RemoteID = $(Throw "Provide the remote id to apply to the VM"),
        [Parameter(Mandatory=$true)]
        [Int] $RequestID = $(Throw "Provide the request ID for the Service Request")
        )

########################################################################################################################
# Setting Cert Policy - required for successful auth with the Rubrik API if set to https
########################################################################################################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

$rubrikCreds = "YWSGESVEFSEGHJWRYWElY3JldDE="

$rubrikSessionHeader = @{Authorization=("Basic {0}" -f $rubrikCreds)}
$contentType = "application/json"

    #address of your vCommander server
    $vCommanderServer = "localhost" 
    #Credential file to access your vCommander install, this must be prepared in advance
    $CredFile = 'c:\scripts\vCommanderCreds.xml'

$LastSnapshotCAName = "Last Snapshot Timestamp"

########################################################################################################################
# Variables Passed in by vCommander passed in on the provisioning workflow for a VM
########################################################################################################################


$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}


$Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client


    $Form = Get-ChangeRequestFormDetails -RequestID $RequestID
    $FormDetails = $Form.RequestFormElementCollection.RequestFormElements

$TakeSnapshot = ($FormDetails | where {$_.label -eq "Take Rubrik Snapshot?"}).value
$ClearSnapshots = ($FormDetails | where {$_.label -eq "Clear Previous Snapshots?"}).value
$ClearDate = ($FormDetails | where {$_.label -eq "Clear Snapshots Before"}).value
$ApplySLA = ($FormDetails | where {$_.label -eq "Apply SLA?"}).value

Write-host "TargetVM: $TargetVMName"
Write-Host "Target Remote ID: $RemoteID"

########################################################################################################################
# Customer Configured Variables
########################################################################################################################

$rubrikIP = "https://10.10.20.11"


########################################################################################################################
# Get VMs by Name
########################################################################################################################
$isNotFound = $true

$VMPath = "$rubrikIP/api/v1/vmware/vm?name=$TargetVMName"

while($isNotFound)
{
    Try
    {
	    $VMJSON = Invoke-WebRequest -Uri $VMPath -Headers $rubrikSessionHeader -Method GET
	    $VMs = ConvertFrom-Json -InputObject $VMJSON.Content
        $VMs = $VMs.data


    }Catch {
	    Write-Host "Failed to retrieve selected VM" -ForegroundColor Red
	    Exit 1
    }  

    ########################################################################################################################
    # Get specific VM ID by remote (vCenter) ID
    ########################################################################################################################

    $selectedVM = $VMs | Where-Object {$_.moid -eq $RemoteID}

    if(!$selectedVM)
    {
        Write-Host "Failed to retrieve selected VM"
        Exit 1
    }
    else
    {
        Write-Host "Selected VM found"
        $VMRubrikID = $selectedVM.id

        #Break while loop
        $isNotFound = $false
    }     
}

########################################################################################################################
# POST VM to take Snapshot
########################################################################################################################
if($TakeSnapshot -eq "Yes")
{
    if($ApplySLA -eq "Yes")
    {
        $SLAID = $selectedVM.effectiveSlaDomainId
    }
    else
    {
        $SLAID = "UNPROTECTED"
    }

    $SnapShotJSON = 
    '{
      "slaId" : "'+$SLAID+'"    
     }'

    $SnapshotPath = "$rubrikIP/api/v1/vmware/vm/$VMRubrikID/snapshot"

    Try
    {
	    $SNAPRESPONSE = Invoke-WebRequest -Uri $SnapshotPath -Headers $rubrikSessionHeader -Body $SnapShotJSON -Method POST
        $SnapResponseJSON =  $SNAPRESPONSE.content | ConvertFrom-Json	    

    }Catch {
	    Write-Host "Failed to take the Snapshot" -ForegroundColor Red
        $error[0] | Format-List -Force
	    Exit 1
    }  

    Write-Host "The snapshot has been requested"

    $SnapStastus = $SnapResponseJSON.status
    $SnapStatusURL = "$rubrikIP/api/v1/vmware/vm/request/"+$SnapResponseJSON.id

    While($SnapStastus -eq "RUNNING")
    {
        Try
        {
	        $SnapJSON = Invoke-WebRequest -Uri $SnapStatusURL -Headers $rubrikSessionHeader -Method GET
            $SnapResponseJSON =  $SnapJSON.content | ConvertFrom-Json
		    $SnapStastus = $SnapResponseJSON.status
        }Catch {
	        Write-Host "Failed to take the Snapshot" -ForegroundColor Red
            $error[0] | Format-List -Force
	        Exit 1
        }  
    }

    if($SnapStastus -eq "SUCCEEDED")
    {
        Write-Host "The Snapshot is complete"
    }
    elseif($SnapStastus -eq "QUEUED")
    {
        Write-Host "The Snapshot has been Queued and will complete shortly"
    }
    else
    {
        Write-Host ("Failed to take the Snapshot. Status: "+$SnapStatus) -ForegroundColor Red
        Exit 1
    }
    

    ########################################################################################################################
    # Store Snapshot datetime in the VMs Custom Attribute
    ########################################################################################################################

    $vCommanderVm = Get-VMByRemoteId -vmRemoteId $RemoteID

    $lastSnapshotTime = $vCommanderVm.VirtualMachineCollection.VirtualMachines[0].attributes | where {$_.attribute.name -eq $LastSnapshotCAName}

    if(!$lastSnapshotTime)
    {
        $Attribute = Get-CustomAttributeByName -name $LastSnapshotCAName

        $newAttrib = New-DTOTemplateObject -DTOTagName "CustomAttribute"
        $newAttrib.CustomAttribute.name = $Attribute.CustomAttribute.name
        $newAttrib.CustomAttribute.description = $Attribute.CustomAttribute.description 
        $newAttrib.CustomAttribute.value = Get-Date -UFormat "%Y/%m/%d"
        $newAttrib.CustomAttribute.targetManagedObjectTypes = $Attribute.CustomAttribute.targetManagedObjectTypes 
            
        Set-Attribute -vmId $vCommanderVm.VirtualMachineCollection.VirtualMachines[0].id -customAttributeDTo $newAttrib   
    }

    Write-Host "Snapshot saved, VM Custom Attribute updated"
}
else
{
    Write-Host "No snapshots requested"
}