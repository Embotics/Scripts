﻿<#
Description: Script that calls out to Rubrik to take an On Demand Snapshot
Requirements: 
-VComamnder 6.1.4 or higher
-Powershell V4 or greater


Note:
Your Environment may require additional or different logic depending on how Rubrik has been configured.

vCommander workflow Run Syntax:
powershell.exe c:\Scripts\Rubrik\Rubrik_OnDemand_Snapshot.ps1 -TargetVMName "#{target.deployedName}" -RemoteID "#{target.remoteId}"
#>



[CmdletBinding()]
	param(
        [Parameter(Mandatory=$True)]
        [String] $TargetVMName = $(Throw "Provide the VM Name to target"),        
		[Parameter(Mandatory=$True)]
        [String] $RemoteID = $(Throw "Provide the remote id to apply to the VM"),
        [Parameter(Mandatory=$true)]
        [Int] $RequestID = $(Throw "Provide the request ID for the Service Request")
        )

########################################################################################################################
# Setting Cert Policy - required for successful auth with the Rubrik API if set to https
########################################################################################################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

$rubrikCreds = "YWSGESVEFSEGHJWRYWElY3JldDE="

$rubrikSessionHeader = @{Authorization=("Basic {0}" -f $rubrikCreds)}
$contentType = "application/json"

    #address of your vCommander server
    $vCommanderServer = "localhost" 
    #Credential file to access your vCommander install, this must be prepared in advance
    $CredFile = 'c:\scripts\vCommanderCreds.xml'

$LastSnapshotCAName = "Last Snapshot Timestamp"

########################################################################################################################
# Variables Passed in by vCommander passed in on the provisioning workflow for a VM
########################################################################################################################


$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}


$Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client


    $Form = Get-ChangeRequestFormDetails -RequestID $RequestID
    $FormDetails = $Form.RequestFormElementCollection.RequestFormElements

$TakeSnapshot = ($FormDetails | where {$_.label -eq "Take Rubrik Snapshot?"}).value
$ClearSnapshots = ($FormDetails | where {$_.label -eq "Clear Previous Snapshots?"}).value
$ClearDate = ($FormDetails | where {$_.label -eq "Clear Snapshots Before"}).value

Write-host "TargetVM: $TargetVMName"
Write-Host "Target Remote ID: $RemoteID"

########################################################################################################################
# Customer Configured Variables
########################################################################################################################

$rubrikIP = "https://10.10.20.11"


########################################################################################################################
# Get VMs by Name
########################################################################################################################
$isNotFound = $true

$VMPath = "$rubrikIP/api/v1/vmware/vm?name=$TargetVMName"

while($isNotFound)
{
    Try
    {
	    $VMJSON = Invoke-WebRequest -Uri $VMPath -Headers $rubrikSessionHeader -Method GET
	    $VMs = ConvertFrom-Json -InputObject $VMJSON.Content
        $VMs = $VMs.data


    }Catch {
	    Write-Host "Failed to retrieve selected VM" -ForegroundColor Red
	    Exit 1
    }  

    ########################################################################################################################
    # Get specific VM ID by remote (vCenter) ID
    ########################################################################################################################

    $selectedVM = $VMs | Where-Object {$_.moid -eq $RemoteID}

    if(!$selectedVM)
    {
        Write-Host "Failed to retrieve selected VM"
        Exit 1
    }
    else
    {
        Write-Host "Selected VM found"
        $VMRubrikID = $selectedVM.id

        #Break while loop
        $isNotFound = $false
    }     
}

########################################################################################################################
# Check if we should clear old snapshots
########################################################################################################################
If($ClearSnapshots -eq "Yes" -and $ClearDate)
{
    ########################################################################################################################
    # Get the list of Snapshots for that VM
    ########################################################################################################################
    $SnapShotListURL =  "$rubrikIP/api/v1/vmware/vm/$VMRubrikID/snapshot"
    Try
    {
	    $SnapListJSON = Invoke-WebRequest -Uri $SnapShotListURL -Headers $rubrikSessionHeader -Method GET
        $SnapListResponseJSON =  $SnapListJSON.content | ConvertFrom-Json
        $SnapListValues = $SnapListResponseJSON.data        

    }Catch {
	    Write-Host "Failed to load Snapshots" -ForegroundColor Red
        $error[0] | Format-List -Force
	    Exit 1
    }  

    while($SnapListResponseJSON.hasMore)
    {
        $PagingURL = $SnapShotListURL+"?offset="+$SnapListValues.Count
        Try
        {
	        $SnapListJSONAddon = Invoke-WebRequest -Uri $SnapShotListURL -Headers $rubrikSessionHeader -Method GET
            $SnapListResponseJSONAddon =  $SnapListJSONAddon.content | ConvertFrom-Json

            $SnapListValues += $SnapListResponseJSONAddon.data
		   
        }Catch {
	        Write-Host "Failed to load all Snapshots" -ForegroundColor Red
            $error[0] | Format-List -Force
	        Exit 1
        }  
    }

    ########################################################################################################################
    # For each snap, if it is older than the ClearDate, remove it
    ########################################################################################################################
    $ClearDateDTObj = Get-Date -Date $ClearDate

    foreach($snapshot in $SnapListValues)
    {       
        $DateofSnap = Get-Date -Date $snapshot.date

        if($DateofSnap -lt $ClearDateDTObj)
        {
            $DeleteSnapURL =  "$rubrikIP/api/v1/vmware/vm/snapshot/"+$snapshot.id+"?location=all"
            Try
            {
                Write-host "Attempting to delete snapshot "$snapshot.id" with timedstamp "$snapshot.date

	            $DeleteSnapJSON = Invoke-WebRequest -Uri $DeleteSnapURL -Headers $rubrikSessionHeader -Method DELETE
                
                Write-Host "Delete in progress for snapshot "$snapshot.id" with timedstamp "$snapshot.date
                	   
            }Catch {
	            Write-Host "Unable to delete Snapshot "$snapshot.id" with timedstamp "$snapshot.date -ForegroundColor Red
                    $MessageObj = $error[0].ErrorDetails.Message | ConvertFrom-Json
                Write-Host $MessageObj.message
            }  
        }
    }
}
else
{
    Write-Host "No deletions requested"
}

