﻿<#
Description: Script that calls out to Rubrik to remove an SLA from the VM in the completion workflow
Requirements: 
-VComamnder 6.1.4 or higher
-Powershell V4 or greater


Note:
Your Environment may require additional or diffrent logic depending on how Rubrik has been configured.

vCommander workflow Run Syntax:
powershell.exe c:\Scripts\Rubrik\Rubrik_Deprovisioning_Workflow.ps1 -TargetVMName "#{target.deployedName}" -RemoteID "#{target.remoteId}"
#>



[CmdletBinding()]
	param(
        [Parameter(Mandatory=$True)]
        [String] $TargetVMName = $(Throw "Provide the VM Name to target"),        
		[Parameter(Mandatory=$True)]
        [String] $RemoteID = $(Throw "Provide the remote id to apply to the VM")        
        )

########################################################################################################################
# Setting Cert Policy - required for successful auth with the Rubrik API if set to https
########################################################################################################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

########################################################################################################################
# Customer Configured Variables
########################################################################################################################

$rubrikIP = "https://10.10.20.11"

$rubrikCreds = "YWSGESVEFSEGHJWRYWElY3JldDE="

$rubrikSessionHeader = @{Authorization=("Basic {0}" -f $rubrikCreds)}
$contentType = "application/json"

########################################################################################################################
# Variables Passed in by vCommander passed in on the provisioning workflow for a VM
########################################################################################################################

Write-host "TargetVM: $TargetVMName"
Write-Host "Target Remote ID: $RemoteID"



########################################################################################################################
# Get VMs by Name
########################################################################################################################
$isNotFound = $true

$VMPath = "$rubrikIP/api/v1/vmware/vm?name=$TargetVMName"

while($isNotFound)
{
    Try
    {
	    $VMJSON = Invoke-WebRequest -Uri $VMPath -Headers $rubrikSessionHeader -Method GET
	    $VMs = ConvertFrom-Json -InputObject $VMJSON.Content
        $VMs = $VMs.data


    }Catch {
	    Write-Host "Failed to find VM" -ForegroundColor Red
	    Exit 1
    }  

    ########################################################################################################################
    # Get specific VM ID by remote (vCenter) ID
    ########################################################################################################################

    $selectedVM = $VMs | Where-Object {$_.moid -eq $RemoteID}

    if(!$selectedVM)
    {
        Write-Host "No VM found"
        Exit 1
    }
    else
    {
        Write-Host "VM found"
        $VMRubrikID = $selectedVM.id

        #Break while loop
        $isNotFound = $false
    }     
}

########################################################################################################################
# PATCH VM to remove SLA
########################################################################################################################
$VMPatchSLAJSON = 
'{
  "configuredSlaDomainId" : "INHERIT"    
 }'

$VMPatchPath = "$rubrikIP/api/v1/vmware/vm/$VMRubrikID"

Try
{
	$VMJSON = Invoke-WebRequest -Uri $VMPatchPath -Headers $rubrikSessionHeader -Body $VMPatchSLAJSON -Method PATCH
		
}Catch {
	Write-Host "Failed to remove the selected SLA " -ForegroundColor Red
    $error[0] | Format-List -Force
	Exit 1
}  

Write-Host "The selected SLA has been removed"


