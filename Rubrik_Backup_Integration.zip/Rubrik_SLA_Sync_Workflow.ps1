﻿<#
Description: Script that calls out to Rubrik torefresh SLAs stored in vCommander
Requirements: 
-VComamnder 6.1.4 or higher
-Powershell V4 or greater


Note:
Your Environment may require additional or diffrent logic depending on how Rubrik has been configured.

vCommander workflow Run Syntax:
powershell.exe c:\Scripts\Rubrik\Rubrik_SLA_Sync_Workflow.ps1
#>


	
########################################################################################################################
# Setting Cert Policy - required for successful auth with the Rubrik API if set to https
########################################################################################################################
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;



########################################################################################################################
# Customer Configured Variables
########################################################################################################################
$rubrikIP = "https://10.10.20.11"

$rubrikCreds = "YWSGESVEFSEGHJWRYWElY3JldDE="

$rubrikSessionHeader = @{Authorization=("Basic {0}" -f $rubrikCreds)}
$contentType = "application/json"

    #address of your vCommander server
    $vCommanderServer = "localhost" 
    #Credential file to access your vCommander install, this must be prepared in advance
    $CredFile = 'c:\scripts\vCommanderCreds.xml'

########################################################################################################################
# Variables Passed in by vCommander passed in on the provisioning workflow for a VM
########################################################################################################################


$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}


$Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client

########################################################################################################################
# Get list of SLAs 
########################################################################################################################
$SLAPath = "$rubrikIP/api/v1/sla_domain"

Try
	{
		$SLAJSON = Invoke-WebRequest -Uri $SLAPath -Headers $rubrikSessionHeader -Method GET
		$SLAs = ConvertFrom-Json -InputObject $SLAJSON.Content
        $SLAs = $SLAs.data

	}Catch {
		Write-Host "Failed to retrieve SLAs" -ForegroundColor Red
		$error[0] | Format-List -Force
		Exit 1
	}  

########################################################################################################################
# Get list of Custom Attributes 
########################################################################################################################

$SLACa = Get-CustomAttributeByName -name "Rubrik SLA"
if (!($SLACa.CustomAttribute.allowedValues)) 
{
    Add-Member -InputObject $SLACa.CustomAttribute -MemberType NoteProperty -Name "allowedValues" -Value @() -Force
}  

$SLAList = @()

foreach ($sla in $SLAs)
{
    $SLAList += $sla.name
}


$SLACa.CustomAttribute.allowedValues = $SLAList

Update-CustomAttribute -id $SLACa.CustomAttribute.id -customAttributeDTo $SLACa

Write-Host "Update complete"