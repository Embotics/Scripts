﻿<#
Name: New Tenant Onboarding Sample Scrip
Purpose: This scrip creates a new organization, organization owner, organization resource quota, deployment destinations and networking configuration using a single Service Request
Required Inputs: vCommander Service Request ID
Outputs: None
Published: 05/03/2018
Author: Chad Veinotte

Log messages are returned to the Comments of the Service Request. Some conditions may terminate the script process.
In those cases the Service Request will Fail and any avaiable error details will be provided in the Service Request Comments

Execution Call: powershell.exe  -ExecutionPolicy Bypass  &{C:\scripts\New_Tenant_Onboarding.ps1 '#{request.id}'}
#>

param(
    [Parameter(Mandatory=$true)]
    [Int] $requestid   
)

<#
Imports/Required modules
#>

import-module VMware.VimAutomation.Core

$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}


####################################################################
### Edit these for your Environment
#################################################################### 
  
    #address of your vCommander server
    $vCommanderServer = "localhost" 
    #Credential file to access your vCommander install, this must be prepared in advance
    $CredFile = 'c:\scripts\vCommanderCreds.xml'

    #Credential file to access your Active Directory install, this must be prepared in advance
    $ADDCCredFile = 'c:\scripts\ADCreds.xml'
    
    #Credentials file for vCenter
    $vCenterCredFile = 'c:\scripts\VCenterCreds.xml'

    #Set this value to True if you want to use Active Directory in this integration
    $usingActiveDirectory = $false

####################################################################
###               Do not Edit below this Line                    ###
#################################################################### 
    
<#
Connect to the vCommander system
#>    
    $Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client

<#
Load the Service Request Form using the Service Request ID
#>
    $requestedService = Get-RequestedServices -requestId $requestId
    $requestedServiceId = $requestedService.RequestedServiceCollection.RequestedServices.id
    $requestedComponent = Get-RequestedComponents -requestId $requestId -requestedServiceId $requestedServiceId
    $requestedComponentId = $requestedComponent.RequestedComponentCollection.RequestedComponents.id
    $Form = Get-RequestedComponentFormDetails -requestedComponentId $requestedComponentId -requestedServiceId $requestedServiceId -requestId $requestId
    $FormDetails = $Form.RequestFormElementCollection.RequestFormElements

<#
Load the form field values from the Form Details
#>
    #Org details
    $OrganizationName = $FormDetails | where-object {$_.label -eq 'Organization Name'} | Select -Expandproperty value
    $OrgManagerEmailAddress = $FormDetails | where-object {$_.label -eq 'Organization Manager Email'} | Select -Expandproperty value
    
    #Quota Details
    $CPUQuota = $FormDetails | where-object {$_.label -eq 'CPU Quota'} | Select -Expandproperty value
    $MemoryQuota = $FormDetails | where-object {$_.label -eq 'Memory Quota'} | Select -Expandproperty value
    $StorageQuota = $FormDetails | where-object {$_.label -eq 'Storage Quota'} | Select -Expandproperty value

    #Destination Details    
    $DestinationFoldersString = $FormDetails | where-object {$_.label -eq 'Destination Folders List'} | Select -Expandproperty value
    $DestinationFoldersList = $DestinationFoldersString.Split(",",[StringSplitOptions]'RemoveEmptyEntries')
    
	#Manage Server details
	$VCenterDataCenter = $FormDetails | where-object {$_.label -eq 'Data Center'} | Select -Expandproperty value    
    $ManagedServiceName = $FormDetails | where-object {$_.label -eq 'Managed Systems'} | Select -Expandproperty value
    $ClusterName = $FormDetails | where-object {$_.label -eq 'Cluster'} | Select -Expandproperty value
    $DataStoreName = $FormDetails | where-object {$_.label -eq 'Datastore'} | Select -Expandproperty value
    $NetworkName = $FormDetails | where-object {$_.label -eq 'Network'} | Select -Expandproperty value

    <#
		Optional:
		- This section can be enabled to confirm a connection to the Active Directory server.
		- If the server is not reached an error is thrown and the script will halt.
    
    $ADDCAddress = $FormDetails | where-object {$_.label -eq 'AD Domain Controller Address'} | Select -Expandproperty value #'gammapdc.ad.gamma.pv'
    $ADCredentials = (New-DecryptCredential -keyFilePath $ADDCCredFile) 
    
    #Test AD Connection
    $ADDCConnectionTestResult = Test-Connection -computer $ADDCAddress -quiet
    if (!$ADDCConnectionTestResult) {
        
        Throw “The ActiveDirectory server $ADDCAddress could not be reached. Connectivity to the specified server could not be established.”
    }
    #>

<#
Organization Manager Setup
#>
    #Check if the Org Manager user already exists locally
    $ExistingUser = $null
    try
    {
        $ExistingUser = Get-Account -loginId $OrgManagerEmailAddress
    }
    catch
    {
        $ExistingUser = $null
    }

    if($ExistingUser)
    {        
        Write-host "The user ($OrgManagerEmailAddress) already exists in vCommander, continuing"
    }
    else
    {
        Write-host "The user ($OrgManagerEmailAddress) does not exists in vCommander, attempting to add user to vCommander"

        <#
			Optional:
			- This section can be enabled to validate if the user account exists in Active Directory.
			- If the user is not found in the Active Directory system the script throws an error and halts.
		
        #connect the remote session to the AD DC    
        $session = new-pssession -ComputerName $ADDCAddress -Credential $ADCredentials

        #prepare variables to pass into remote session
        $remoteParams = $OrganizationName, $OrgManagerEmailAddress

        
        Begin remote execution on the AD DC
        
        invoke-command -session $session  -ArgumentList $remoteParams -ScriptBlock {   
            #Parameters List
            param ($OrganizationName, $OrgManagerEmailAddress)

            #Set executionpolicy to bypass warnings in this session
            Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
               
            #Check if the Org Manger exists in AD
            $ADUser = Get-ADUser -Filter {UserPrincipalName -eq $OrgManagerEmailAddress}
            if($ADUser)
            {
                Write-Host "The Organization Manager ($OrgManagerEmailAddress) exists in Active Directory, continuing"                
            }
            else
            {               
               Throw "The Organization Manager ($OrgManagerEmailAddress) does not exist in Active Directory, this script cannot continue"
            } 
        }    
        Remove-PSSession $ADDCAddress
        #>

        #Since the user account does not appear in vCommander we will need to create the user in vCommander
        $newVCAccount = New-DTOTemplateObject -DTOTagName "Account"
        $newVCAccount.Account.userid = $OrgManagerEmailAddress

        #if using AD integration, we set the account type to DIRECTORY USER, if using the local vCommander Accounts we set it to local
        if($usingActiveDirectory)
        {
            $newVCAccount.Account.securitySourceType = "USER_DIRECTORY_USER"  
        }
        else
        {
            $newVCAccount.Account.securitySourceType = "LOCAL"

            #Since this is a local account, we need to generate a new random password for the user
            $newVCAccount.Account.password = -join ((65..90) + (97..122) | Get-Random -Count 12 | % {[char]$_}) + (Get-Random -Minimum -0 -Maximum 9) + "!"
        }
        

        #Get a vCommander Role to the user
        $roles = Get-Roles
        $selectedRole = $roles.RoleCollection.roles | where-object {$_.name -eq 'Manager'}

        #apply the selected Role
        $newVCAccount.Account.role = $selectedRole
               

        $ExistingUser = $null
        try
        {
            #Finish Org Manager account creation
            $ExistingUser = New-Account -accountDto $newVCAccount
        }
        catch
        {
            Throw "The user could not be created, the script cannot continue"
        }
    }

<#
Organization Creation
#>
    #compose the Organization User to add to the Org
    $userDTO = New-DTOTemplateObject -DTOTagName "OrganizationUser"
    $userDTO.OrganizationUser.userId = $ExistingUser.Account.userid
    $userDTO.OrganizationUser.manager = $true
    $userDTO.OrganizationUser.portalRole = 'Manager'

    #Create a new resource quota DTO
    $resourceQuota = New-DTOTemplateObject -DTOTagName "ResourceQuota"
    $resourceQuota.ResourceQuota.CPUCount = $CPUQuota
    $resourceQuota.ResourceQuota.memoryInGB = $MemoryQuota
    $resourceQuota.ResourceQuota.stoppedVmsAllowPowerOn = $true
    $resourceQuota.ResourceQuota.stoppedVmsCalculateOnlyStorage = $true
    $resourceQuota.ResourceQuota.storageInGB =  $StorageQuota
    
    #Create an organization DTO
    $orgDto = New-DTOTemplateObject -DTOTagName "Organization"
    
    #Specify organization details
    $orgDto.Organization.name = $OrganizationName
    $orgDto.Organization.resourceQuota = $resourceQuota.ResourceQuota

    #Add the Org User to the Org
    $orgDto.Organization.Members = @()
    $orgDto.Organization.Members += $userDTO.OrganizationUser

    #Create the new Organization
    $newOrgTask = New-Organization -orgDto $orgDto

    #we now wait until the task completes
    while($newOrgTask.TaskInfo.finalState -eq $false)
    {
        $newOrgTask = Get-TaskInfo -Id $newOrgTask.TaskInfo.id
    }  
    
    #The Organization is now created and we can configure destinations and folders

<#
Connect to the vCenter and query/create the required folders
#>
    #Look up the vCenter by name
    $vCenterItem = Get-ManagementServers
    $vCenterItem = $vCenterItem.ManagementServerCollection.ManagementServers | Where-Object {$_.displayName -eq $ManagedServiceName}
   
    #Connect to vCenter      
    $vCenterCredentials = (New-DecryptCredential -keyFilePath $VCenterCredFile) 
    $vCenterServer = Connect-VIServer -Server $vCenterItem.address -Credential $vCenterCredentials
    
    #Create the Folder for the Tenant using the Organization Name
    $targetDatacenter = Get-Datacenter $VCenterDataCenter
    $vmFolderView = (Get-View (Get-View -viewtype datacenter –filter @{"name"=$VCenterDataCenter}).vmfolder)

    $orgFolder = $vmFolderView.CreateFolder($OrganizationName) 
    Start-Sleep -s 5

    if(!$orgFolder)
    {
        Write-host "Could not create the Root Folder ($OrganizationName) for the Organization"
        Throw "Could not create the Root Folder ($OrganizationName) for the Organization"
    }
    
    #Create the Destination Names used for deployment destinations for this Org    
	foreach ($destinationFolder in $DestinationFoldersList)
	{
		#Clean whitespace from the Folder Name
		$cleanFolderName = $destinationFolder.Trim()
		#Compose the Destination Name"
		$DestinationName = "$OrganizationName-$ManagedServiceName-$cleanFolderName"
		
		$vCenterFolder = New-Folder -Name $destinationFolder -Location $OrganizationName

		Start-Sleep -s 5
				
		#Find the Folders in vCommander with the same name as our Destination folder
		$SelectedVCommanderFolders = Get-FoldersByName -name $destinationFolder
        foreach($fld in $SelectedVCommanderFolders.FolderCollection.Folders)
        {
            if( $vCenterFolder.Id -match $fld.remoteId )
            {
                  $SelectedVCommanderFolder = $fld
            }

        }
		
		#Get the vCenter Management Server for this vCenter
		$ManagedObjectCollection = Get-ManagedObjectByName -name $ManagedServiceName -type "MANAGEMENTSERVER"
		$ManagementServer = $ManagedObjectCollection.ManagedObjectCollection.managedObjects
		$ManagementServerID = $ManagedObjectCollection.ManagedObjectCollection.ManagedObjectReferences.id

		$HostInfo = (Get-RuntimeServers -msId $ManagementServerID).runtimeservercollection.runtimeservers | Where-Object {$_.parentResource.displayname -eq $ClusterName}            
		$HostID = ($Hostinfo[0]).id
		$cluster = Get-ClusterByName -msId $ManagementServer.id -clusterName $ClusterName

		$DatastoreID = ($HostInfo.mountedDatastores.datastore | Where-Object {$_.displayname -eq $DataStoreName})[0].id
		$DataStoreCollection = Get-ManagedObject -id $DatastoreID -type "DATASTORE"
		$SelectedDataStore = $DataStoreCollection.ManagedObjectCollection.managedObjects[0]
		
		#Select the list of networks matching the name, then filter to the one for this host and network type  
		$SelectedNetworkList = Get-ManagedObject -name $NetworkName -type "NETWORK"           
		$SelectedNetwork = $SelectedNetworkList.ManagedObjectCollection.managedObjects | Where-Object {$_.hosts.id -eq $HostID -and $_.networkType -eq "STANDARD"}
		
		#Create the Destination in vCommander
		$ddDTO = New-DTOTemplateObject -DTOTagName "VMWareDeploymentDestination"
		$ddDTO.VMWareDeploymentDestination.name = $DestinationName
		$ddDTO.VMWareDeploymentDestination.assignIpFromPool = $false
		$ddDTO.VMWareDeploymentDestination.diskFormat = "THIN" #Possible values are THICK, THIN, and SAME_AS_SOURCE. See DiskFormat DTO.
		$ddDTO.VMWareDeploymentDestination.peakCapacity = $false #to use average capacity, set to $false
		$ddDTO.VMWareDeploymentDestination.managementServer = $ManagementServer
		$ddDTO.VMWareDeploymentDestination.folder = $SelectedVCommanderFolder
		$ddDTO.VMWareDeploymentDestination.target = $cluster.Cluster
		$ddDTO.VMWareDeploymentDestination.datastores = @($SelectedDataStore)
		$ddDTO.VMWareDeploymentDestination.network = $SelectedNetwork
        
        $selectedOrg = Get-ManagedObject -type "ORGANIZATION" -name $OrganizationName

        if (!($ddDTO.VMWareDeploymentDestination.organizations)) 
        {
            Add-Member -InputObject $ddDTO.VMWareDeploymentDestination -MemberType NoteProperty -Name "organizations" -Value @() -Force
        }
        
        $ddDTO.VMWareDeploymentDestination.organizations = @($selectedOrg.ManagedObjectCollection.ManagedObjectReferences)
                
		#Instance the new Destination
		try
		{
			$createDD = New-VMWareDeploymentDestination -ddDto $ddDTO
		}
		catch
		{
			Write-Host $PSItem			               
		}
	}