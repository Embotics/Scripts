﻿<#
Name: Sync Custom Attributes Sample Script
Purpose: This scrip creates and populates the custom attributes required for the New Tenant Onboarding process to function.
Required Inputs: None
Outputs: None
Published: 05/03/2018
Author: Chad Veinotte

Log messages are returned to the Comments of the Service Request. Some conditions may terminate the script process.
In those cases the Service Request will Fail and any avaiable error details will be provided in the Service Request Comments

Execution Call: powershell.exe  -ExecutionPolicy Bypass  &{C:\scripts\Sync_Custom_Attributes.ps1}
#>

<#
Imports/Required modules
#>

 

$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}

####################################################################
### Edit these for your Environment
#################################################################### 
  
    #address of your vCommander server
    $vCommanderServer = "vcommander Server Address" 
    #Credential file to access your vCommander install, this must be prepared in advance
    $CredFile = 'c:\scripts\vCommanderCreds.xml'

####################################################################
###               Do not Edit below this Line                    ###
#################################################################### 

    $managedSystemsCustomAttributeName = "Managed Systems"
    $networksSublistCustomAttributeName = "Network"
    $dataCentersSublistCustomAttributeName = "Data Center"
    $datastoresSublistCustomAttributeName = "Datastore"   
    $clustersSublistCustomAttributeName = "Cluster"   

	#Connect to vCommander
    $Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    $connected = Connect-Client
    
   
	
	#Get Managed Systems List from vCommander custom attribute, if it is not found, create it.
    try
    {
        $managedSystems = Get-CustomAttributeByName -name $managedSystemsCustomAttributeName
    }
    catch [Microsoft.PowerShell.Commands.WriteErrorException]
    {
        Write-host "$managedSystemsCustomAttributeName custom attribute not found, creating custom attribute"

        #Create Custom Attribute DTO
        $caDTO = New-DTOTemplateObject -DTOTagName "CustomAttribute"
        $caDto.CustomAttribute.name = $managedSystemsCustomAttributeName
        $caDto.CustomAttribute.description = ""
        $caDto.CustomAttribute.allowedValues = @("Placeholder")
        $caDto.CustomAttribute.targetManagedObjectTypes = "ALL"

        $managedSystems = New-CustomAttribute -customAttributeDTo $caDTO
    }
	
    #Get the Network, Cluster, Data Center and Datastore sublists, if any of these are not found, create them.        
    try
    {
        $DataCentersSublist = Get-CustomAttributeByName -name $dataCentersSublistCustomAttributeName
        
    }
    catch [Microsoft.PowerShell.Commands.WriteErrorException]
    {
        Write-host "$dataCentersSublistCustomAttributeName custom attribute not found, creating custom attribute"

        #Create Custom Attribute DTO
        $caDTO = New-DTOTemplateObject -DTOTagName "SubListCustomAttribute"
        $caDto.SubListCustomAttribute.name = $dataCentersSublistCustomAttributeName    
        $caDto.SubListCustomAttribute.description = ""    
        $caDto.SubListCustomAttribute.targetManagedObjectTypes = "ALL"
        $caDTO.SubListCustomAttribute.sublistOfAttribute = $managedSystemsCustomAttributeName
        $caDTO.SubListCustomAttribute.allowedValues = @{"Placeholder" = @()}
        
        $DataCentersSublist = New-CustomAttribute -customAttributeDTo $caDTO

        $caDTO = $null
    }

     try
    {
        $DataStoresSublist = Get-CustomAttributeByName -name $datastoresSublistCustomAttributeName
        
    }
    catch [Microsoft.PowerShell.Commands.WriteErrorException]
    {
        Write-host "$datastoresSublistCustomAttributeName custom attribute not found, creating custom attribute"

        #Create Custom Attribute DTO
        $caDTO = New-DTOTemplateObject -DTOTagName "SubListCustomAttribute"
        $caDto.SubListCustomAttribute.name = $datastoresSublistCustomAttributeName  
        $caDto.SubListCustomAttribute.description = ""       
        $caDto.SubListCustomAttribute.targetManagedObjectTypes = "ALL"
        $caDTO.SubListCustomAttribute.sublistOfAttribute = $managedSystemsCustomAttributeName
        $caDTO.SubListCustomAttribute.allowedValues = @{"Placeholder" = @()}
        
        $DataStoresSublist = New-CustomAttribute -customAttributeDTo $caDTO

        $caDTO = $null
    }

    try
    {
        $ClustersSublist = Get-CustomAttributeByName -name $clustersSublistCustomAttributeName
        
    }
    catch [Microsoft.PowerShell.Commands.WriteErrorException]
    {
        Write-host "$clustersSublistCustomAttributeName custom attribute not found, creating custom attribute"

        #Create Custom Attribute DTO
        $caDTO = New-DTOTemplateObject -DTOTagName "SubListCustomAttribute"
        $caDto.SubListCustomAttribute.name = $clustersSublistCustomAttributeName    
        $caDto.SubListCustomAttribute.description = ""     
        $caDto.SubListCustomAttribute.targetManagedObjectTypes = "ALL"
        $caDTO.SubListCustomAttribute.sublistOfAttribute = $managedSystemsCustomAttributeName
        #since the cluster will be referenced by the Network sublist the allowed value needs to be populated as well.
        $caDTO.SubListCustomAttribute.allowedValues = @{"Placeholder" = @("Placeholder")}
        
        $ClustersSublist = New-CustomAttribute -customAttributeDTo $caDTO

        $caDTO = $null
    }

    #Get the Network Sublist, create if it does not exist. The Network list is a sublist of Cluster, not Managed System
    try
    {
        $NetworksSublist = Get-CustomAttributeByName -name $networksSublistCustomAttributeName
        
    }
    catch [Microsoft.PowerShell.Commands.WriteErrorException]
    {
        Write-host "$networksSublistCustomAttributeName custom attribute not found, creating custom attribute"

        #Create Custom Attribute DTO
        $caDTO = New-DTOTemplateObject -DTOTagName "SubListCustomAttribute"
        $caDto.SubListCustomAttribute.name = $networksSublistCustomAttributeName   
        $caDto.SubListCustomAttribute.description = ""      
        $caDto.SubListCustomAttribute.targetManagedObjectTypes = "ALL"
        $caDTO.SubListCustomAttribute.sublistOfAttribute = $clustersSublistCustomAttributeName
        $caDTO.SubListCustomAttribute.allowedValues = @{"Placeholder" = @()}
        
        $NetworksSublist = New-CustomAttribute -customAttributeDTo $caDTO

        $caDTO = $null
    }           
    
    $sublists = $DataCentersSublist,$DataStoresSublist,$NetworksSublist,$ClustersSublist

    #prepare each sublist
    foreach($item in $sublists)
    {
		#If the list is empty and has not been populated we must add the allowedValues property to the sublist
        if (!($item.SubListCustomAttribute.allowedValues)) 
        {
            Add-Member -InputObject $item.SubListCustomAttribute -MemberType NoteProperty -Name "allowedValues" -Value @() -Force
        }        
        
		#Set the sublist to only contain the placeholder entry
        $item.SubListCustomAttribute.allowedValues = @{"Placeholder" = @("placeholder")}

		#Now that the sublist has been cleared and set with a placeholder value, push the new sublist back into vCommander
        try
        {
            Update-CustomAttribute -id $item.SublistCustomAttribute.id -customAttributeDTo $item
        }
        catch
        {
               Write-host "Unable to update "$item.SubListCustomAttribute.name
        }        
    }
    
    #Get the list of managed services from vCommander, we will use this to populate the Managed Systems custom attribute
    $currentSystems = Get-ManagementServers
    
    #Clear the Managed Service list and add only the placeholder item
    $managedSystems.CustomAttribute.allowedValues = @("Placeholder")

    #for each managed service in vCommander
    foreach($result in $currentSystems.ManagementServerCollection.ManagementServers)
    {       
       #if the service is a vCenter system
       if($result.serverType -eq "VMWARE_VC")
       {
			#add the managed service to the Managed Service list attribute
            $managedSystems.CustomAttribute.allowedValues += $result.name
       }               
    }

	#now that the Managed Service list attribute is updated, push it back into vCommander
    Update-CustomAttribute -id $managedSystems.CustomAttribute.id -customAttributeDTo $managedSystems
            
    #Get updated Managed Systems list from vCommander custom attribute
    $managedSystems = Get-CustomAttributeByName -name $managedSystemsCustomAttributeName

    #Get the sublist custom attributes
    $NetworksSublist = Get-CustomAttributeByName -name $networksSublistCustomAttributeName
    $ClustersSublist = Get-CustomAttributeByName -name $clustersSublistCustomAttributeName
    $DataCentersSublist = Get-CustomAttributeByName -name $dataCentersSublistCustomAttributeName
    $DataStoresSublist = Get-CustomAttributeByName -name $datastoresSublistCustomAttributeName
       
    #trim the services list to only include the vCeneter type servers
    $vCenterServices = $currentSystems.ManagementServerCollection.ManagementServers | Where-Object {$_.serverType -eq "VMWARE_VC"}

    #For each service in the set, collect the sublist components
    foreach($service in $vCenterServices)
    {       
        #Get and update the Data Centers
        $dataCenters = Get-Datacenters -msId $service.id
        foreach($dc in $dataCenters.DatacenterCollection.Datacenters)
        {
            #if the KEY already exists, then add the VALUE to that key-set
            if($DataCentersSublist.SubListCustomAttribute.allowedValues[$service.name] -notcontains $dc.name)
            {
                $DataCentersSublist.SubListCustomAttribute.allowedValues[$service.name] += @($dc.name)
            }
        }

        Update-CustomAttribute -id $DataCentersSublist.SubListCustomAttribute.id -customAttributeDTo $DataCentersSublist

        #Get and update the Datastores for this Data Center
        $RuntimeServers = (Get-RuntimeServers -msId $service.id).runtimeservercollection.runtimeservers
            
        $dataStores = @()
        foreach($rs in $RuntimeServers)
        {
            $dataStores += $rs.mountedDatastores
        }
        

        foreach($ds in $dataStores)
        {
            if($ds -ne $null -and $DataStoresSublist.SubListCustomAttribute.allowedValues[$service.name] -notcontains $ds.datastore.displayName)
            {                
                $DataStoresSublist.SubListCustomAttribute.allowedValues[$service.name] += @($ds.datastore.displayName)
            } 
        }
        
        Update-CustomAttribute -id $DataStoresSublist.SubListCustomAttribute.id -customAttributeDTo $DataStoresSublist
        

        #Get and update the Clusters
        $clusters = Get-Clusters -msId $service.id
        
        foreach($cl in $clusters.ManagedObjectReferenceCollection.ManagedObjectReferences)
        {
            if($cl -ne $null -and $ClustersSublist.SubListCustomAttribute.allowedValues[$service.name] -notcontains $cl.displayName)
            {                
                $ClustersSublist.SubListCustomAttribute.allowedValues[$service.name] += @($cl.displayName)
            } 

            #Networks are dependent on Clusters so we get and update the Networks for each Cluster
            $networks = Get-AvailableNetworks -clusterid $cl.id

            foreach($nw in $networks.ManagedObjectReferenceCollection.ManagedObjectReferences)
            {                
                if($nw -ne $null -and $NetworksSublist.SubListCustomAttribute.allowedValues[$cl.displayName] -notcontains $nw.displayName)
                {
                    $NetworksSublist.SubListCustomAttribute.allowedValues[$cl.displayName] += @($nw.displayName)
                } 
            }
        }

        Update-CustomAttribute -id $ClustersSublist.SubListCustomAttribute.id -customAttributeDTo $ClustersSublist
        
        Update-CustomAttribute -id $NetworksSublist.SubListCustomAttribute.id -customAttributeDTo $NetworksSublist
    }
