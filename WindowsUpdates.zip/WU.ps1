﻿if ($PSVersionTable.PSVersion.Major -ccontains "5")
{
Write-Host "Powershell 5.0 Detected Continuing with script execution"
Start-Transcript
#Install Nuget
    try 
        {
        Install-PackageProvider nuget -force
        Import-PackageProvider nuget -Force
        }

    catch 
        {
        Write-Host "Failed to Install nuget"
        Exit 1
        }


#Set PS repository
    try 
        {
        Set-PSRepository -name psgallery -installationpolicy trusted
        }

    catch 
        {
        Write-Host "Failed to Set PS Repository"
        Exit 1
        }


#Install Windows Update
   try 
        {
        Install-Module pswindowsupdate
        Import-Module PSWindowsUpdate
        get-command -module pswindowsupdate
        }

    catch 
        {
        Write-Host "Failed to Install Windows Update Modules"
        Exit 1
        }



#Get Updates from Microsoft

  try 
        {
        Add-WUServiceManager -ServiceID 7971f918-a847-4430-9279-4a52d1efe18d -Confirm:$false
        }

    catch 
        {
        Write-Host "Failed to Add Windows Update Manager"
        Exit 1
        }

#Install Updates and Reboot
  try 
        {
        Get-WUInstall -WindowsUpdate -AcceptAll -Download -Install -AutoReboot 
        }

    catch 
        {
        Write-Host "Failed to Install Windows Updates"
        Exit 1
        }

Stop-Transcript
}
else 
{
Write-Host "Powershell Version 5 or higher is required to run this script"
}