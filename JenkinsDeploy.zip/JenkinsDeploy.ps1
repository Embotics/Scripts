﻿<#
Requirements:
- vCommander Rest API 2.7 installed on the Jenkins server making the calls to vCommander
- Powershell addin must be installed on the Jenkins Server.
- Powershell Version 4
#>

$vCommanderServer = 'your.vCommander.com'
$CredFile = 'c:\scripts\superuser.xml'
$BuildNumber = "$env:BUILD_NUMBER"
$ServiceRequestarray = "Win7 Service" #Comma delimit to request multiple services "Win8.1","Win10"
$TTL = '7' # Number of days for the service to live (Set Expiry)

#Remove and re-add the modules 
Write-Host "Loading Modules"
$moduleName = "VCommanderRestClient"

If (-not (Get-Module -name $moduleName)) {
                Import-Module -Name $moduleName 
} else {
                Remove-Module $moduleName
                Import-Module -Name $moduleName 
}
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {
                Import-Module -Name $moduleName 
} else {
                Remove-Module $moduleName
                Import-Module -Name $moduleName 
}

Start-Sleep -Seconds 5
#Connecting to vCommander
    $Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
	$cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client

#Set Expiry base on TTL
$ExpiryDate = (get-date).AddDays($TTL).ToString("yyy/MM/dd")

#Request a new service
ForEach($SO in $ServiceRequestarray){
        #Locate an appropriate service
        $ps = Get-PublishedServiceByName -name "$SO"
        $requestParams = Get-PSRequestParams -psId $ps.PublishedService.id
   
        #Pull out service form elements
        Write-Host "get Service form elements"
        #Pull out service form elements
        $BuildNumberElement = $requestParams.PSDeployParamCollection.serviceformElements.RequestFormElements | Where-Object {$_.label -eq "Build Number"}
        $ExpiryDateElement = $requestParams.PSDeployParamCollection.serviceformElements.RequestFormElements | Where-Object {$_.label -eq "Expiry Date"}
   
        #Configure correct form values
        Write-Host "Configure Service form elements"
        $BuildNumberElement.value = $BuildNumber
        $ExpiryDateElement.value = $ExpiryDate
   
        #Repeat for all components
        Write-host "Request name equals $SO"
        $component1DeployParam = $requestParams.PSDeployParamCollection.componentParams
   
        #Pull out all the component form elements so we can pull out the data (repeat for all components)
        #Write-Host "Get component form elements"
        #$BuildNumberElement = $component1DeployParam.formElements.RequestFormElements | Where-Object {$_.label -eq "$Build Number"}
        #$VMNameElement = $component1DeployParam.formElements.RequestFormElements | Where-Object {$_.label -eq "VM Name"}
   
        #Configure correct form values
        Write-Host "Configure Service form elements"
        $BuildNumberElement.value = "$BuildNumber"
   
        #Submit the request
        Write-Host "Submit the request"
        $requestDTO = New-ServiceRequest -psId $ps.PublishedService.id -requestParams $requestParams
        Write-Host 'Submission Complete'
        }