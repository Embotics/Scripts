﻿
<#
Execution Call: powershell.exe  -ExecutionPolicy Bypass  &{C:\scripts\Export_To_OVF.ps1 -requestID "#{request.id}" -targetManagedServer "#{target.managedSystem.address}" -targetVMDNS "#{target.dnsName}" }
#>

param(
    [Parameter(Mandatory=$true)]
    [String] $targetManagedServer,
    [Parameter(Mandatory=$true)]
    [String] $targetVMDNS
)

########################################################################################################################
# Customer Configured Variables
########################################################################################################################

#address of your vCommander server
$vCommanderServer = "localhost" 
#Credential file to access your vCommander install, this must be prepared in advance
$CredFile = 'c:\scripts\vCommanderCreds.xml'
#Credential file to access vCenter
$vCenterCredFile = "c:\scripts\vCenterCredentials.xml"
#Location of the text file used to accept the rsa key when connecting to the vCenter system
$RSAContinueFilePath = "C:\scripts\RSAProceed.txt"
#Location to save the OVF Files
$OVFExportLocation = "c:\scripts\"

########################################################################################################################
# Variables Passed in by vCommander passed in on the provisioning workflow for a VM
########################################################################################################################

Write-Host "Loading Modules"

$moduleName = "VCommanderRestClient"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName } 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName }
$moduleName = "VCommander"
If (-not (Get-Module -name $moduleName)) {Import-Module -Name $moduleName} 
else {Remove-Module $moduleName
        Import-Module -Name $moduleName}

Write-Host "Connecting to vCommander"

$Global:SERVICE_HOST = $vCommanderServer
    $Global:REQUEST_HEADERS =@{}
    $Global:BASE_SERVICE_URI = $Global:BASE_SERVICE_URI_PATTERN.Replace("{service_host}",$Global:SERVICE_HOST)   
    $cred = (New-DecryptCredential -keyFilePath $CredFile) 	
    $Global:CREDENTIAL = $cred
    VCommander\Set-IgnoreSslErrors
    Connect-Client

$vCenterCreds = New-DecryptCredential -keyFilePath $vCenterCredFile

$vCenterUser = $vCenterCreds.UserName
$vCenterPassword = $vCenterCreds.GetNetworkCredential().password

Write-Host "Target VM: $targetVMDNS"

Write-Host "Cleaning username"

$interimUser = $vCenterUser -replace '!', '%21' `
             -replace '"', '%22' `
             -replace '\#', '%23' `
             -replace '\$', '%24' `
             -replace '\&', '%26' `
             -replace '\(', '%28' `
             -replace '\)', '%29' `
             -replace '\*', '%2a' `
             -replace '\+', '%2b' `
             -replace '\,', '%2c' `
             -replace '\-', '%2d' `
             -replace '\.', '%2e' `
             -replace '\/', '%2f' `
             -replace '\"', '%22' `
             -replace '\\', '%5c'

Write-Host "Cleaning Password"

$interimPassword = $vCenterPassword -replace '!', '%21' `
             -replace '"', '%22' `
             -replace '\#', '%23' `
             -replace '\@', '%40' `
             -replace '\$', '%24' `
             -replace '\&', '%26' `
             -replace '\(', '%28' `
             -replace '\)', '%29' `
             -replace '\*', '%2a' `
             -replace '\+', '%2b' `
             -replace '\,', '%2c' `
             -replace '\-', '%2d' `
             -replace '\.', '%2e' `
             -replace '\/', '%2f' `
             -replace '\"', '%22' `
             -replace '\<', '%3c' `
             -replace '\>', '%3e' `
             -replace '\?', '%3f' `
             -replace '\:', '%3a' `
             -replace '\;', '%3b' `
             -replace '\{', '%7b' `
             -replace '\}', '%7d' `
             -replace '\[', '%5b' `
             -replace '\]', '%5d' `
             -replace '\|', '%7c' `
             -replace '\^', '%5e'

Write-Host "Creating commands"

$command = '"'+"C:\Program Files (x86)\VMware\VMware OVF Tool\ovftool.exe"+'"'
$powerSwitch = "--powerOffSource "
$source = '"'+"vi://"+$interimUser+":"+"$interimPassword"+"@"+"$targetManagedServer"+"/?dns=$targetVMDNS"+'"'
$target = '"'+"$OVFExportLocation"+"$targetVMDNS.ovf"+'"'

$params  = @()
$params += $powerSwitch
$params += $source
$params += $target

Try
{
    #try to write and remove a file to the destination folder
    "vCommander VM to OVF Export Script - Write Permissions Test" | Out-File $OVFExportLocation"vCommander_VM_to_OVF_Write_test.txt"
}
Catch
{
    Write-Host "Unable to write test file to $OVFExportLocation - The vCommander User must have WRITE permission on the selected folder" -ForegroundColor Red
	Exit 1
}

$proc = Start-Process $command -ArgumentList $params -PassThru -RedirectStandardInput $RSAContinueFilePath -wait